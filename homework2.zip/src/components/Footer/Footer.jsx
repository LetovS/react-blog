import './Footer.css';

const Footer = () => {
    return (
        <footer className="footer">
            <p>© 2025 Мое React Приложение</p>
        </footer>
    );
};

export default Footer;