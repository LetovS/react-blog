const Works = () => {
    return (
        <div>
            <h1>Мои работы</h1>
            <p>Здесь будут показаны мои проекты.</p>
        </div>
    );
};

export default Works;